# CallScreeningEnabler
## README.md
### Copyright (C) 2018, J0S3Gabriel




---
#### DESCRIPTION

Add scripts to Digital Wellbeing application to enable "Flip To Shhh" to work in any device with android 9 and up



---
#### PRE-REQUISITES

- Magisk 18.0
- Android 9+
- Latest Digital Wellbeing APK installed



---
#### SETUP STEPS

1. Remove any/all similar module(s).
2. Install/upgrade from Magisk Manager.
3. Reboot. 
